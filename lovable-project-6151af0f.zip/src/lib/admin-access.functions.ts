import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Emails allowed to hold the admin role for the enquiries dashboard. */
const ADMIN_EMAILS = ["brightmaryada@gmail.com"];

/**
 * Grants the admin role to the signed-in user when their email is on the
 * allowlist. Safe to call on every visit to the admin page.
 */
export const ensureAdminAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const email = String(context.claims?.email ?? "").toLowerCase();
    if (!ADMIN_EMAILS.includes(email)) return { isAdmin: false };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("user_roles")
      .upsert(
        { user_id: context.userId, role: "admin" },
        { onConflict: "user_id,role", ignoreDuplicates: true },
      );

    if (error) {
      console.error("[ensureAdminAccess]", error);
      return { isAdmin: false };
    }

    return { isAdmin: true };
  });
