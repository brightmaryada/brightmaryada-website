import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listEnquiries = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;

    // Verify the caller has the admin role. RLS also enforces this, but we
    // check explicitly so we can return a clear error before querying.
    const { data: hasAdmin, error: roleError } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });

    if (roleError || !hasAdmin) {
      return {
        enquiries: [],
        deniedReason:
          "This account does not have admin access. Sign in with the company admin email.",
      };
    }

    const { data, error } = await supabase
      .from("enquiries")
      .select("id, name, company, email, phone, enquiry_type, message, created_at")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("[listEnquiries]", error);
      return { enquiries: [], deniedReason: "Failed to load enquiries." };
    }

    return { enquiries: data ?? [], deniedReason: null as string | null };
  });
