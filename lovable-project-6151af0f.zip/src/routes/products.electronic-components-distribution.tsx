import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Reveal } from "@/components/site/Reveal";
import {
  ArrowRight,
  Boxes,
  Cable,
  CircuitBoard,
  Cpu,
  HardDrive,
  Layers,
  Mail,
  Phone,
  MemoryStick,
  Sparkles,
  Truck,
  Warehouse,
} from "lucide-react";

import electronicComponents from "@/assets/electronic-components.jpg";

const title = "Electronic Components Distributor | Bright Maryada Distribution Pvt Ltd";
const description =
  "Bright Maryada Distribution Pvt Ltd supplies ICs, microcontrollers, passive components, connectors, and PCB assemblies to businesses across India. Reliable B2B electronic components distribution.";

export const Route = createFileRoute("/products/electronic-components-distribution")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://brightmaryada.com/products/electronic-components-distribution" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      {
        rel: "canonical",
        href: "https://brightmaryada.com/products/electronic-components-distribution",
      },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          name: "Electronic Components Distribution",
          provider: {
            "@type": "Organization",
            name: "Bright Maryada Distribution Pvt Ltd",
            url: "https://brightmaryada.com/",
            email: "brightmaryada@gmail.com",
          },
          description,
          areaServed: {
            "@type": "Country",
            name: "India",
          },
        }),
      },
    ],
  }),
  component: ElectronicComponentsPage,
});

function SectionLabel({ children }: { children: string }) {
  return (
    <p className="mb-4 text-xs font-semibold tracking-[0.28em] text-primary">{children}</p>
  );
}

const components = [
  {
    icon: Cpu,
    title: "Integrated Circuits",
    copy: "Microcontrollers, processors, logic ICs and application-specific chips for embedded, industrial and consumer applications.",
  },
  {
    icon: CircuitBoard,
    title: "PCB Assemblies",
    copy: "Printed circuit boards and assembly components sourced to support prototyping and production runs.",
  },
  {
    icon: Layers,
    title: "Passive Components",
    copy: "Resistors, capacitors, inductors, crystals, oscillators and filters from dependable supply lines.",
  },
  {
    icon: Cable,
    title: "Connectors & Cables",
    copy: "Headers, terminals, wire harnesses, RF connectors and data cables for board-level and system integration.",
  },
  {
    icon: MemoryStick,
    title: "Memory & Storage",
    copy: "DRAM modules, Flash memory, SSDs and memory controllers for computing and embedded devices.",
  },
  {
    icon: HardDrive,
    title: "Power & Protection",
    copy: "Power management ICs, voltage regulators, diodes, transistors and ESD protection devices.",
  },
];

const capabilities = [
  {
    icon: Warehouse,
    title: "Consolidated Sourcing",
    copy: "We aggregate demand across suppliers to simplify procurement and reduce component lead times.",
  },
  {
    icon: Boxes,
    title: "Volume Flexibility",
    copy: "From small engineering batches to scaled production volumes, with quotes tailored to project needs.",
  },
  {
    icon: Truck,
    title: "India-Wide Logistics",
    copy: "Distribution across metro and tier-2 markets with a logistics model focused on reliability and traceability.",
  },
  {
    icon: Sparkles,
    title: "Lifecycle Support",
    copy: "We help businesses plan for component availability, alternates and end-of-life transitions.",
  },
];

function ElectronicComponentsPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero */}
        <section className="relative flex min-h-[80vh] items-center overflow-hidden">
          <img
            src={electronicComponents}
            alt="Electronic components and integrated circuits on a printed circuit board"
            width={1600}
            height={900}
            className="drift-slow absolute inset-0 size-full object-cover opacity-55"
          />
          <div className="veil absolute inset-0" />
          <div className="absolute -left-40 top-1/3 size-[34rem] rounded-full bg-primary/12 blur-[140px]" />

          <div className="relative mx-auto w-full max-w-7xl px-6 pt-28">
            <Reveal>
              <div className="glass-panel inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium tracking-wide text-muted-foreground">
                <CircuitBoard className="size-3.5 text-primary" />
                B2B Electronic Components
              </div>
            </Reveal>
            <Reveal delay={120}>
              <h1 className="mt-8 max-w-4xl text-[2.6rem] leading-[1.04] sm:text-6xl lg:text-7xl">
                <span className="text-accent-gradient">Electronic Components</span>
                <br />
                Distributor in India
              </h1>
            </Reveal>
            <Reveal delay={240}>
              <p className="mt-8 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
                Bright Maryada Distribution Pvt Ltd connects manufacturers and system integrators with
                the ICs, passive components, connectors and PCB assemblies they need to keep production
                moving.
              </p>
            </Reveal>
            <Reveal delay={340}>
              <div className="mt-11 flex flex-wrap gap-4">
                <a
                  href="#components"
                  className="inline-flex items-center gap-2 rounded-md bg-primary px-7 py-3.5 text-sm font-semibold text-primary-foreground transition-all hover:brightness-115"
                >
                  Explore Components <ArrowRight className="size-4" />
                </a>
                <a
                  href="#contact"
                  className="glass-panel inline-flex items-center rounded-md px-7 py-3.5 text-sm font-semibold transition-colors hover:border-primary/50"
                >
                  Request a Quote
                </a>
              </div>
            </Reveal>
          </div>
        </section>

        {/* Component types */}
        <section id="components" className="relative border-y border-border bg-surface/40 py-28 lg:py-36">
          <div className="mx-auto max-w-7xl px-6">
            <Reveal>
              <SectionLabel>COMPONENT CATEGORIES</SectionLabel>
              <h2 className="max-w-2xl text-3xl leading-tight sm:text-5xl">
                Components We Source and Distribute
              </h2>
              <p className="mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground">
                Our portfolio covers the building blocks of modern electronics — from active
                semiconductors to passive parts, connectors and power devices.
              </p>
            </Reveal>

            <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {components.map((c, i) => (
                <Reveal key={c.title} delay={i * 80}>
                  <div className="card-hover glass-panel h-full rounded-xl p-8">
                    <c.icon className="size-7 text-primary" />
                    <h3 className="mt-8 text-xl">{c.title}</h3>
                    <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{c.copy}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* Distribution capabilities */}
        <section className="relative overflow-hidden py-28 lg:py-36">
          <div className="absolute left-1/2 top-0 size-[40rem] -translate-x-1/2 rounded-full bg-primary/8 blur-[160px]" />
          <div className="relative mx-auto max-w-7xl px-6">
            <Reveal>
              <div className="mx-auto max-w-2xl text-center">
                <SectionLabel>DISTRIBUTION CAPABILITIES</SectionLabel>
                <h2 className="text-3xl leading-tight sm:text-5xl">Built for B2B Component Supply</h2>
                <p className="mt-6 text-base leading-relaxed text-muted-foreground">
                  We combine sourcing relationships, demand planning and logistics to keep your BOM
                  supplied with the right parts at the right time.
                </p>
              </div>
            </Reveal>

            <div className="mt-16 grid gap-6 md:grid-cols-2">
              {capabilities.map((c, i) => (
                <Reveal key={c.title} delay={i * 90}>
                  <div className="card-hover glass-panel h-full rounded-xl p-10">
                    <c.icon className="size-8 text-primary" />
                    <h3 className="mt-10 text-2xl">{c.title}</h3>
                    <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
                      {c.copy}
                    </p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* CTA / Contact */}
        <section id="contact" className="relative overflow-hidden py-28 lg:py-36">
          <img
            src={electronicComponents}
            alt="Electronic components distribution background"
            loading="lazy"
            width={1600}
            height={900}
            className="absolute inset-0 size-full object-cover opacity-25"
          />
          <div className="absolute inset-0 bg-background/80" />
          <div className="veil absolute inset-0 opacity-80" />
          <div className="relative mx-auto max-w-4xl px-6 text-center">
            <Reveal>
              <SectionLabel>GET IN TOUCH</SectionLabel>
              <h2 className="text-3xl leading-tight sm:text-5xl">
                Need a Reliable Electronic Components Distributor?
              </h2>
              <p className="mx-auto mt-7 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
                Share your Bill of Materials or component requirements and our team will get back with
                availability, pricing and lead-time details.
              </p>
            </Reveal>
            <Reveal delay={150}>
              <div className="mt-11 flex flex-wrap justify-center gap-4">
                <a
                  href="mailto:brightmaryada@gmail.com"
                  className="inline-flex items-center gap-2 rounded-md bg-primary px-7 py-3.5 text-sm font-semibold text-primary-foreground transition-all hover:brightness-115"
                >
                  <Mail className="size-4" />
                  brightmaryada@gmail.com
                </a>
                <a
                  href="tel:+918310596804"
                  className="glass-panel inline-flex items-center gap-2 rounded-md px-7 py-3.5 text-sm font-semibold transition-colors hover:border-primary/50"
                >
                  <Phone className="size-4" />
                  +91 83105 96804
                </a>
                <a
                  href="/#contact"
                  className="glass-panel inline-flex items-center rounded-md px-7 py-3.5 text-sm font-semibold transition-colors hover:border-primary/50"
                >
                  Send an Enquiry
                </a>
              </div>
            </Reveal>

          </div>
        </section>

      </main>
      <Footer />
    </div>
  );
}
