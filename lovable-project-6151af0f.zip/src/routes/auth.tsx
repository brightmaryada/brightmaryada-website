import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Lock, Mail } from "lucide-react";

const ADMIN_EMAIL = "brightmaryada@gmail.com";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Admin Sign In | Bright Maryada Distribution Pvt Ltd" },
      { name: "description", content: "Secure admin sign in for Bright Maryada Distribution Pvt Ltd." },
      { property: "og:title", content: "Admin Sign In | Bright Maryada Distribution Pvt Ltd" },
      { property: "og:description", content: "Secure admin sign in for Bright Maryada Distribution Pvt Ltd." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) {
        router.navigate({ to: "/enquiries" });
      } else {
        setIsLoading(false);
      }
    });
  }, [router]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setMessage(null);

    const { error } = await supabase.auth.signInWithOtp({
      email: ADMIN_EMAIL,
      options: {
        shouldCreateUser: true,
        emailRedirectTo: `${window.location.origin}/enquiries`,
      },
    });

    if (error) {
      setMessage("We couldn't send the sign-in link. Please wait a moment and try again.");
      setBusy(false);
      return;
    }

    setSent(true);
    setBusy(false);
  };

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="text-muted-foreground">Checking session…</div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex flex-1 items-center justify-center px-6 py-24">
        <form
          onSubmit={submit}
          className="w-full max-w-md rounded-2xl border border-border bg-surface/60 p-8 shadow-xl"
        >
          <div className="mb-6 inline-flex size-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Lock className="size-6" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Admin Sign In</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Receive a secure sign-in link at the company email to view customer enquiries.
          </p>

          <div className="mt-6 rounded-md border border-border bg-background px-4 py-3">
            <div className="flex items-center gap-3">
              <Mail className="size-4 text-primary" />
              <span className="text-sm font-medium">{ADMIN_EMAIL}</span>
            </div>
          </div>

          {message && (
            <p className="mt-4 text-sm text-destructive">{message}</p>
          )}

          {sent && (
            <div className="mt-4 rounded-md border border-primary/30 bg-primary/10 p-4 text-sm">
              Sign-in link sent. Open the email from this device, then select the link to view enquiries.
            </div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="mt-8 inline-flex w-full items-center justify-center gap-3 rounded-md bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-all hover:brightness-115 disabled:opacity-60"
          >
            {busy ? "Sending…" : sent ? "Send link again" : "Email me a sign-in link"}
          </button>
        </form>
      </main>
      <Footer />
    </div>
  );
}
