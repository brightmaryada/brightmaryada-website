import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms & Conditions | Bright Maryada Distribution Pvt Ltd" },
      {
        name: "description",
        content:
          "Terms governing the use of the Bright Maryada Distribution Pvt Ltd website and the information published on it.",
      },
      { property: "og:title", content: "Terms & Conditions | Bright Maryada Distribution" },
      {
        property: "og:description",
        content: "Terms governing use of the Bright Maryada Distribution website.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://brightmaryada.com/terms" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://brightmaryada.com/terms" }],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="mx-auto max-w-3xl px-6 pb-24 pt-36">
        <h1 className="text-4xl">Terms &amp; Conditions</h1>
        <div className="mt-8 space-y-6 text-sm leading-relaxed text-muted-foreground">
          <p>
            By accessing this website you agree to the terms below. This website is operated by
            Bright Maryada Distribution Pvt Ltd.
          </p>
          <p>
            <strong className="text-foreground">Informational purpose.</strong> Content on this
            website describes our business focus and product categories. It is provided for general
            information and does not constitute an offer, quotation or commitment to supply.
          </p>
          <p>
            <strong className="text-foreground">Enquiries.</strong> Submitting an enquiry does not
            create a contract. Any supply arrangement is subject to a separate written agreement.
          </p>
          <p>
            <strong className="text-foreground">Intellectual property.</strong> The company name,
            website content and design are the property of Bright Maryada Distribution Pvt Ltd and
            may not be reproduced without permission.
          </p>
          <p>
            <strong className="text-foreground">Changes.</strong> We may update this website and
            these terms at any time. Continued use signifies acceptance of the current version.
          </p>
        </div>
        <Link to="/" className="mt-12 inline-block text-sm font-semibold text-primary">
          ← Back to home
        </Link>
      </main>
      <Footer />
    </div>
  );
}
