import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy | Bright Maryada Distribution Pvt Ltd" },
      {
        name: "description",
        content:
          "How Bright Maryada Distribution Pvt Ltd handles enquiry and business information shared through this website.",
      },
      { property: "og:title", content: "Privacy Policy | Bright Maryada Distribution" },
      {
        property: "og:description",
        content: "How we handle enquiry and business information shared with Bright Maryada.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://brightmaryada.com/privacy" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://brightmaryada.com/privacy" }],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="mx-auto max-w-3xl px-6 pb-24 pt-36">
        <h1 className="text-4xl">Privacy Policy</h1>
        <div className="mt-8 space-y-6 text-sm leading-relaxed text-muted-foreground">
          <p>
            Bright Maryada Distribution Pvt Ltd respects the privacy of the businesses and
            individuals who contact us. This page explains what information we collect through this
            website and how it is used.
          </p>
          <p>
            <strong className="text-foreground">Information we collect.</strong> When you submit an
            enquiry, we collect the name, company, email address, phone number and message you
            choose to provide.
          </p>
          <p>
            <strong className="text-foreground">How we use it.</strong> Enquiry details are used only
            to respond to your request and to maintain business correspondence. We do not sell or
            rent your information.
          </p>
          <p>
            <strong className="text-foreground">Sharing.</strong> Information may be shared
            internally with our directors and advisory contacts strictly for the purpose of
            responding to your enquiry.
          </p>
          <p>
            <strong className="text-foreground">Retention and requests.</strong> We keep enquiry
            correspondence for as long as it remains relevant to our business relationship. To
            request correction or deletion of your details, write to{" "}
            <a
              className="text-primary hover:underline"
              href="mailto:brightmaryada@gmail.com"
            >
              brightmaryada@gmail.com
            </a>
            .
          </p>
          <p className="mt-4">
            <strong className="text-foreground">Phone.</strong> You can also reach us at{" "}
            <a className="text-primary hover:underline" href="tel:+918310596804">
              +91 83105 96804
            </a>
            .
          </p>
        </div>
        <Link to="/" className="mt-12 inline-block text-sm font-semibold text-primary">
          ← Back to home
        </Link>
      </main>
      <Footer />
    </div>
  );
}
