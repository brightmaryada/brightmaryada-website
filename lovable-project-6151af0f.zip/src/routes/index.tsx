import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import {
  About,
  Contact,
  DistributionNetwork,
  Hero,
  Leadership,
  Partnerships,
  Products,
  TrustStrip,
  WhyUs,
} from "@/components/site/Sections";

const title = "Bright Maryada Distribution Pvt Ltd | B2B Technology Distribution";
const description =
  "Bright Maryada Distribution Pvt Ltd is building a reliable B2B technology distribution network for memory, storage, components and technology accessories.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://brightmaryada.com/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://brightmaryada.com/" }],

    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          name: "Bright Maryada Distribution Pvt Ltd",
          url: "https://brightmaryada.com/",
          description,
          email: "brightmaryada@gmail.com",
        }),
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <TrustStrip />
        <About />
        <Products />
        <DistributionNetwork />
        <WhyUs />
        <Partnerships />
        <Leadership />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
