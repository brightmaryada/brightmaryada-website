import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { listEnquiries } from "@/lib/enquiries.functions";
import { ensureAdminAccess } from "@/lib/admin-access.functions";
import { LogOut, Mail, Phone, Building2, Calendar, Tag, AlertCircle } from "lucide-react";

export const Route = createFileRoute("/_authenticated/enquiries")({
  head: () => ({
    meta: [
      { title: "Customer Enquiries | Bright Maryada Distribution Pvt Ltd" },
      { name: "description", content: "Private admin view of customer enquiries for Bright Maryada Distribution Pvt Ltd." },
      { property: "og:title", content: "Customer Enquiries | Bright Maryada Distribution Pvt Ltd" },
      { property: "og:description", content: "Private admin view of customer enquiries." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: EnquiriesPage,
});

function EnquiriesPage() {
  const fetchEnquiries = useServerFn(listEnquiries);
  const grantAccess = useServerFn(ensureAdminAccess);
  const { data: access, error: accessError, isLoading: isCheckingAccess } = useQuery({
    queryKey: ["admin-access"],
    queryFn: () => grantAccess({ data: undefined }),
    retry: false,
  });
  const { data: result, isLoading, error } = useQuery({
    queryKey: ["enquiries", access?.isAdmin],
    queryFn: fetchEnquiries,
    enabled: access?.isAdmin === true,
    retry: false,
  });
  const enquiries = result?.enquiries;
  const deniedReason = result?.deniedReason ?? null;

  const signOut = async () => {
    await supabase.auth.signOut();
    window.location.href = "/auth";
  };

  const formatDate = (value: string) => {
    return new Date(value).toLocaleString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-surface/60">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div>
            <h1 className="text-xl font-bold tracking-tight">Customer Enquiries</h1>
            <p className="text-sm text-muted-foreground">Private admin view</p>
          </div>
          <button
            onClick={signOut}
            className="inline-flex items-center gap-2 rounded-md border border-border bg-background px-4 py-2 text-sm font-semibold transition-colors hover:bg-accent"
          >
            <LogOut className="size-4" />
            Sign out
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-6 py-10">
        {(isCheckingAccess || (access?.isAdmin && isLoading)) && (
          <div className="rounded-xl border border-border bg-surface/40 p-12 text-center text-muted-foreground">
            Loading enquiries…
          </div>
        )}

        {!isCheckingAccess && (accessError || access?.isAdmin === false) && (
          <div className="rounded-xl border border-destructive/30 bg-destructive/10 p-6 text-destructive">
            <div className="flex items-center gap-2 font-semibold">
              <AlertCircle className="size-5" />
              No access
            </div>
            <p className="mt-1 text-sm opacity-90">
              Please sign out and use the link sent to brightmaryada@gmail.com.
            </p>
          </div>
        )}

        {!isCheckingAccess && access?.isAdmin && !isLoading && !error && deniedReason && (
          <div className="rounded-xl border border-destructive/30 bg-destructive/10 p-6 text-destructive">
            <div className="flex items-center gap-2 font-semibold">
              <AlertCircle className="size-5" />
              No access
            </div>
            <p className="mt-1 text-sm opacity-90">{deniedReason}</p>
          </div>
        )}

        {access?.isAdmin && error && (
          <div className="rounded-xl border border-destructive/30 bg-destructive/10 p-6 text-destructive">
            <div className="flex items-center gap-2 font-semibold">
              <AlertCircle className="size-5" />
              Could not load enquiries
            </div>
            <p className="mt-1 text-sm opacity-90">{error.message}</p>
          </div>
        )}

        {access?.isAdmin && !isLoading && !error && !deniedReason && enquiries?.length === 0 && (
          <div className="rounded-xl border border-border bg-surface/40 p-12 text-center text-muted-foreground">
            No enquiries yet.
          </div>
        )}

        {access?.isAdmin && !isLoading && !error && enquiries && enquiries.length > 0 && (
          <div className="space-y-6">
            {enquiries.map((enquiry) => (
              <div
                key={enquiry.id}
                className="rounded-xl border border-border bg-surface/60 p-6 shadow-sm transition-colors hover:border-primary/30"
              >
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <h2 className="text-lg font-semibold">{enquiry.name}</h2>
                    {enquiry.company && (
                      <div className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
                        <Building2 className="size-4" />
                        {enquiry.company}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="size-4" />
                    {formatDate(enquiry.created_at)}
                  </div>
                </div>

                <div className="mt-4 flex flex-wrap gap-4 text-sm">
                  <a
                    href={`mailto:${enquiry.email}`}
                    className="inline-flex items-center gap-1.5 text-primary hover:underline"
                  >
                    <Mail className="size-4" />
                    {enquiry.email}
                  </a>
                  {enquiry.phone && (
                    <a
                      href={`tel:${enquiry.phone}`}
                      className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-foreground"
                    >
                      <Phone className="size-4" />
                      {enquiry.phone}
                    </a>
                  )}
                  <div className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
                    <Tag className="size-3.5" />
                    {enquiry.enquiry_type}
                  </div>
                </div>

                <div className="mt-4 whitespace-pre-wrap text-sm leading-relaxed text-foreground/90">
                  {enquiry.message}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
