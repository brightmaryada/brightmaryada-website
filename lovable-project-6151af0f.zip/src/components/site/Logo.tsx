type LogoProps = {
  size?: "sm" | "md";
  className?: string;
};

export function Logo({ size = "sm", className = "" }: LogoProps) {
  const badge = size === "md" ? "size-12 text-lg" : "size-10 text-base sm:size-11 sm:text-lg";
  const name = size === "md" ? "text-xl sm:text-2xl" : "text-lg sm:text-xl";
  const sub = size === "md" ? "text-[11px]" : "text-[10px]";

  return (
    <span className={`flex items-center gap-3 ${className}`}>
      <span
        className={`${badge} grid shrink-0 place-items-center rounded-xl border border-primary/40 bg-primary/12 font-display font-bold tracking-tight text-primary`}
        aria-hidden="true"
      >
        BM
      </span>
      <span className="flex flex-col leading-none">
        <span className={`${name} font-display font-extrabold tracking-tight text-primary`}>
          BRIGHT MARYADA
        </span>
        <span
          className={`${sub} mt-1.5 hidden font-semibold uppercase tracking-[0.32em] text-foreground sm:block`}
        >
          Distribution Pvt Ltd
        </span>
      </span>
    </span>
  );
}
