import { Link } from "@tanstack/react-router";
import { Logo } from "@/components/site/Logo";

const nav = [
  { label: "Home", href: "/#home" },
  { label: "About", href: "/#about" },
  { label: "Products", href: "/#products" },
  { label: "Partnerships", href: "/#partnerships" },
  { label: "Contact", href: "/#contact" },
];

export function Footer() {
  return (
    <footer className="relative border-t border-border bg-surface/40">
      <div className="mx-auto grid max-w-7xl gap-12 px-6 py-16 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Logo size="md" />


          <p className="mt-4 text-sm text-muted-foreground">
            Technology meets opportunity.
          </p>
        </div>

        <div>
          <p className="text-xs font-semibold tracking-[0.2em] text-muted-foreground">NAVIGATE</p>
          <ul className="mt-4 space-y-2.5">
            {nav.map((l) => (
              <li key={l.label}>
                <a
                  href={l.href}
                  className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="text-xs font-semibold tracking-[0.2em] text-muted-foreground">CONTACT</p>
          <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
            <li>
              <a href="mailto:brightmaryada@gmail.com" className="block hover:text-foreground">
                brightmaryada@gmail.com
              </a>
            </li>
            <li>
              <a href="tel:+918310596804" className="block hover:text-foreground">
                +91 83105 96804
              </a>
            </li>
            <li>
              <a href="/#contact" className="block hover:text-foreground">
                Send an enquiry
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-6 py-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p>© 2026 Bright Maryada Distribution Pvt Ltd. All Rights Reserved.</p>
          <div className="flex gap-6">
            <Link to="/privacy" className="hover:text-foreground">
              Privacy Policy
            </Link>
            <Link to="/terms" className="hover:text-foreground">
              Terms &amp; Conditions
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
