# Brighter Logo Mark for Bright Maryada

The uploaded logo image currently sits in the header and footer, but its text reads dark and dim against the navy background.

## What to build

A custom-designed logo lockup that replaces the flat uploaded image, using a strict two-colour palette:

- **Electric blue** (the site's existing accent) for the "BRIGHT MARYADA" wordmark and the mark
- **Warm white** for "DISTRIBUTION PVT LTD" and secondary strokes

No third colour anywhere in the mark.

## Design direction

- A compact square/rounded "BM" monogram badge in electric blue, paired to the right with the stacked wordmark.
- "BRIGHT MARYADA" set large, bold, tight tracking, in bright blue so it visibly pops against the dark header.
- "DISTRIBUTION PVT LTD" underneath in small, wide-tracked white caps.
- Scales down cleanly: on mobile only the monogram plus "BRIGHT MARYADA" shows.

## Where it applies

- Header (desktop + mobile)
- Footer, same lockup at a slightly larger size
- Favicon stays as-is (already the BM monogram in the same blue)

## Technical notes

- Build the lockup as a small reusable `Logo` component using the existing design tokens (`--primary`, `--foreground`) — no hardcoded hex, so it stays theme-correct.
- Rendered as text + CSS rather than a raster image, so it stays crisp at every size and keeps the company name searchable/accessible.
- The uploaded logo image file stays in the project, unused by the header/footer.
