# Bright Maryada — Task Roadmap

## Done
- [x] Fix Google Search Console setup (`gsc:gsc`)
- [x] Private admin page to view customer enquiries (`/enquiries`)
- [x] Remove all director phone/email details site-wide; single common email brightmaryada@gmail.com
- [x] Directors listed by name only in the home page Leadership section
- [x] Update products section image to Intel-themed photo
- [x] Add contact number +91 83105 96804 below all brightmaryada@gmail.com references
- [x] Remove product cards grid and Explore Components button from products section

## Open
- [ ] Confirm admin sign-in with brightmaryada@gmail.com loads enquiries
